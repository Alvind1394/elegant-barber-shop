type Props = {
  appointmentToken: string;

  onFinish: () => void;
};

export const BookingSuccess = ({
  appointmentToken,
  onFinish,
}: Props) => {
  return (
    <div className="bg-[#111] border border-yellow-500/10 rounded-3xl p-8 text-center">
      <div className="text-6xl mb-6">
        ✅
      </div>

      <h2 className="text-3xl font-bold mb-4">
        Cita confirmada
      </h2>

      <p className="text-gray-400 mb-6">
        Tu código de cita es:
      </p>

      <div className="bg-black border border-yellow-500/20 rounded-2xl p-4 mb-8">
        <span className="text-yellow-400 text-2xl font-bold tracking-widest">
          {appointmentToken}
        </span>
      </div>

      <button
        onClick={onFinish}
        className="w-full bg-yellow-500 text-black font-bold py-4 rounded-2xl"
      >
        Finalizar
      </button>
    </div>
  );
};