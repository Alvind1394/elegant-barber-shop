'use client';

import {
  useEffect,
  useState,
} from 'react';

type Props = {
  timerEnd: string;

  appointmentId: string;

  onAutoComplete: (
    id: string
  ) => void;
};

export const LiveTimer = ({
  timerEnd,
  appointmentId,
  onAutoComplete,
}: Props) => {

  const [
    timeLeft,
    setTimeLeft,
  ] = useState('');

  useEffect(() => {

  const interval =
    setInterval(() => {

      const now =
        Date.now();

      const end =
  new Date(
    timerEnd + 'Z'
  ).getTime();

      const distance =
        end - now;

    if (
  distance <= 0
) {

  setTimeLeft(
    '00:00:00'
  );

  clearInterval(
    interval
  );

  setTimeout(() => {

    onAutoComplete(
      appointmentId
    );

  }, 5000);

  return;
      }

      const hours =
        Math.floor(
          distance /
          (1000 * 60 * 60)
        );

      const minutes =
        Math.floor(
          (
            distance %
            (1000 * 60 * 60)
          ) /
          (1000 * 60)
        );

      const seconds =
        Math.floor(
          (
            distance %
            (1000 * 60)
          ) / 1000
        );

      setTimeLeft(
        `${String(
          hours
        ).padStart(
          2,
          '0'
        )}:${String(
          minutes
        ).padStart(
          2,
          '0'
        )}:${String(
          seconds
        ).padStart(
          2,
          '0'
        )}`
      );

    }, 1000);

  return () =>
    clearInterval(
      interval
    );

}, [timerEnd]);

  return (
    <div
      className={`
        mt-4
        rounded-2xl
        p-4
        text-center
        border

        ${
          timeLeft ===
          '00:00:00'

            ? `
              bg-red-500/10
              border-red-500
            `

            : `
              bg-blue-500/10
              border-blue-500/20
            `
        }
      `}
    >

      <p
        className={`
          text-sm
          mb-1

          ${
            timeLeft ===
            '00:00:00'

              ? 'text-red-300'

              : 'text-blue-300'
          }
        `}
      >
        {
          timeLeft ===
          '00:00:00'

            ? 'TIEMPO TERMINADO'

            : 'Tiempo restante'
        }
      </p>

      <h2
        className={`
          text-3xl
          font-black
          tracking-widest

          ${
            timeLeft ===
            '00:00:00'

              ? 'text-red-400'

              : 'text-blue-400'
          }
        `}
      >
        {timeLeft}
      </h2>

    </div>
  );
};