import { Toaster } from 'sonner';
import './globals.css';
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>
        {children}

        <Toaster richColors />
      </body>
    </html>
  );
}
