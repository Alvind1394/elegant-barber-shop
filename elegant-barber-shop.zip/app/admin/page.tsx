'use client';

import {
  useEffect,
  useState,
} from 'react';

import { useRouter } from 'next/navigation';

import { supabase } from '@/lib/supabase';

import { AdminDashboard } from '@/components/admin/AdminDashboard';

import {
  useAppointments
} from '@/hooks/useAppointments';


import {
  useBlockedDays
} from '@/hooks/useBlockedDays';

export default function AdminPage() {

    const {
  appointments,
  refreshAppointments,
} = useAppointments();

const {
  refreshBlockedDays,
} = useBlockedDays();

  const router =
    useRouter();

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    authorized,
    setAuthorized,
  ] = useState(false);

  useEffect(() => {

    checkAuth();

  }, []);

  const checkAuth =
    async () => {

      const {
        data: { session },
      } =
        await supabase.auth.getSession();

      if (!session) {

       router.push('/');

        return;
      }

      setAuthorized(true);

      setLoading(false);
      

    };

const handleStart =
  async (
    id: string
  ) => {

    const appointment =
      appointments.find(
        (item) =>
          item.id === id
      );

    if (!appointment) {
      return;
    }

    const duration =
      Number(
        appointment.service_duration
      ) || 45;

    // timestamp REAL actual
    const now =
      Date.now();

    // calcular fin REAL
    const endTime =
      now +
      duration *
        60 *
        1000;

    await supabase
      .from('appointments')
      .update({
        status:
          'En progreso',

        started_at:
          new Date(
            now
          ).toISOString(),

        timer_end:
          new Date(
            endTime
          ).toISOString(),
      })
      .eq('id', id);

    refreshAppointments();
  };

const handleComplete =
  async (
    id: string
  ) => {

    await supabase
  .from('appointments')
  .update({
    status: 'Finalizada',
  })
  .eq('id', id);

    refreshAppointments();
  };

const handleDelete =
  async (
    id: string
  ) => {

    const confirmed =
      window.confirm(
        '¿Eliminar cita?'
      );

    if (!confirmed) {
      return;
    }

    await supabase
  .from('appointments')
  .delete()
  .eq('id', id);

    refreshAppointments();
  };


  const logout =
  async () => {

    await supabase.auth.signOut();

    window.location.href = '/';
  };

  if (loading) {

    return (
      <main className="
        min-h-screen
        bg-[#050505]
        flex
        items-center
        justify-center
        text-white
      ">
        Cargando...
      </main>
    );
  }

  if (!authorized) {
    return null;
  }

  return (
    <main className="
      min-h-screen
      bg-[#050505]
      text-white
    ">

      <div className="
        flex
        items-center
        justify-between
        p-6
        border-b
        border-zinc-800
      ">

        <div>

          <h1 className="
            text-3xl
            font-black
            text-yellow-400
          ">
            Admin Dashboard
          </h1>

          <p className="text-zinc-500">
            Panel privado
          </p>

        </div>

        <button
          onClick={logout}
          className="
            bg-red-500
            hover:bg-red-400
            text-white
            px-5
            py-3
            rounded-2xl
            font-bold
          "
        >
          Logout
        </button>

      </div>

      <AdminDashboard
  appointments={
    appointments
  }
  onStart={
  handleStart
}
  onComplete={
    handleComplete
  }
  onDelete={
    handleDelete
  }
  refreshBlockedDays={
    refreshBlockedDays
  }
/>

    </main>
  );
}