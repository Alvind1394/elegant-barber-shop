'use client';

import {
  useEffect,
  useState,
} from 'react';

import { supabase } from '@/lib/supabase';

import { AppointmentType } from '@/types/appointment';

export const useAppointments =
  () => {
    const [
      appointments,
      setAppointments,
    ] = useState<
      AppointmentType[]
    >([]);

    const [loading, setLoading] =
      useState(true);

   const fetchAppointments =
  async () => {

    setLoading(true);

    const { data } =
      await supabase
        .from('appointments')
        .select('*')
        .order('booking_date', {
  ascending: true,
})
.order('booking_hour', {
  ascending: true,
})

    if (data) {
      setAppointments(data);
    }

    setLoading(false);
  };

    useEffect(() => {
      fetchAppointments();

      const channel =
        supabase.channel(
          'appointments-realtime'
        );

      channel
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table:
              'appointments',
          },
          () => {
            fetchAppointments();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(
          channel
        );
      };
    }, []);

 return {
  appointments,

  loading,

  refresh:
    fetchAppointments,

  refreshAppointments:
    fetchAppointments,
};
  };